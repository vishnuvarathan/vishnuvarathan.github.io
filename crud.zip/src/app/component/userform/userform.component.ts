import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { FormBuilder, FormGroup,Validators } from '@angular/forms';
import { Router, ActivatedRouteSnapshot } from '@angular/router';
@Component({
  selector: 'app-userform',
  templateUrl: './userform.component.html',
  styleUrls: ['./userform.component.css']
})
export class UserformComponent implements OnInit {
  userForm: FormGroup;
  submitted: boolean = false;
  constructor(private userService : UserService, private formBuilder : FormBuilder, private router : Router) { }

  ngOnInit() {
    this.setFormGroup();
  }
  setFormGroup(){
    this.userForm = this.formBuilder.group({
      name: ['',Validators.required],
      username: ['',Validators.required],
      email: ['',[Validators.email]],
      address :  ['',Validators.required],
           
   
    });
  }

  onSubmit(form : FormGroup){
    this.submitted = true;
    this.userService.addUser(form.value).subscribe( () => {
      return this.router.navigate(['']);
    });
  }
}
