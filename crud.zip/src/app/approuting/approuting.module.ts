import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ApproutingRoutingModule } from './approuting-routing.module';

@NgModule({
  imports: [
    CommonModule,
    ApproutingRoutingModule
  ],
  declarations: []
})
export class ApproutingModule { }
