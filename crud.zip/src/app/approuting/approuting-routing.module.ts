import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsersComponent } from '../component/users/users.component';
import { UserformComponent } from '../component/userform/userform.component';
import {EditComponent} from '../component/edit/edit.component';
const routes: Routes = [
  {path:'',component:UsersComponent,pathMatch:'full'},
  {path:'users',component:UsersComponent},
  {path:'userform',component:UserformComponent},
  {path:'edit/:id',component:EditComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class ApproutingRoutingModule { }
