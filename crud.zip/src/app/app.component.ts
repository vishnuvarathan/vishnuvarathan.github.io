import { Component } from '@angular/core';
//import { UserService } from './services/user.service';
import {trigger,state,style, transition, animate} from '@angular/animations';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations:[
    trigger('animationTrigger',[
      state('hide',style({
opacity:0
      })),
      state('show',style({
        opacity:1
      })),
      transition('hide<=>show',animate('2s'))
    ])
  ]
})
export class AppComponent {
 // users : any = [];
  constructor() { }
animationState:string='hide';

doAnimation(){
  if(this.animationState=='hide'){
    this.animationState='show';}
    else{
      this.animationState='hide';
    }
  }
}
 

  

