import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ApproutingModule }from './approuting/approuting.module';
import {RouterModule} from '@angular/router';
import { AppComponent } from './app.component';
import { UsersComponent } from './component/users/users.component';
import { UserformComponent } from './component/userform/userform.component';

import { HttpClientModule } from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { UserService } from './services/user.service';
import { EditComponent } from './component/edit/edit.component';
@NgModule({
  declarations: [
    AppComponent,
    UsersComponent,
    UserformComponent,
    EditComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    RouterModule,
    HttpClientModule,
    ApproutingModule,
    ReactiveFormsModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
